const initialUserEditForm = {
  FirstName: "",
  LastName: "",
  email: "",
  phone: "",
  birthDate: "",
  gender: "",
};

export default initialUserEditForm;
