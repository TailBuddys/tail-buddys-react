const initialLoginForm = {
  email: "",
  password: "",
};

export default initialLoginForm;
