const initialCreateDogForm = {
  name: "",
  address: "",
  lon: 0,
  lat: 0,
};

export default initialCreateDogForm;
