const ROUTES = {
  ROOT: "/",
  ABOUT: "/about",
  SIGNUP: "/signup",
  CREATE_DOG: "/create-dog",
  EDIT_DOG: "/edit-dog",
  LOGIN: "/login",
  USER_PROFILE: "/user-info",
  EDIT_USER: "/edit-user",
};

export default ROUTES;
