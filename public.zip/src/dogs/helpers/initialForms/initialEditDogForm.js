const initialEditDogForm = {
  name: "",
  description: "",
  type: "",
  size: "",
  gender: "",
  birthDate: "",
  vaccinated: "",
};

export default initialEditDogForm;
