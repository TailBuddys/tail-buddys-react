import { Box, Typography } from "@mui/material";

const MatchScreenComponent = () => {
  return (
    <Box
      sx={{
        backgroundColor: "#ffb3c1",
      }}
    >
      <Typography>Matches</Typography>
    </Box>
  );
};

export default MatchScreenComponent;
