const initialSignupForm = {
  FirstName: "",
  LastName: "",
  email: "",
  password: "",
  phone: "",
  birthDate: "",
  gender: "",
};

export default initialSignupForm;
