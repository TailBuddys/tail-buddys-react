const ROUTES = {
  ROOT: "/",
  ABOUT: "/about",
  SIGNUP: "/signup",
  CREATE_Dog: "/create-dog",
  EDIT_Dog: "/edit-dog",
  LOGIN: "/login",
  USER_PROFILE: "/user-info",
  EDIT_USER: "/edit-user",
};

export default ROUTES;
