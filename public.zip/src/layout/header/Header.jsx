import React from "react";
import NavBar from "./topNavBar/NavBar";

export default function Header() {
  return <NavBar />;
}
