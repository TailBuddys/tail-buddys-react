import { Box, Typography } from "@mui/material";

const ChatScreenComponent = () => {
  return (
    <Box
      sx={{
        backgroundColor: "#28a745",
      }}
    >
      <Typography>Chats</Typography>
    </Box>
  );
};

export default ChatScreenComponent;
